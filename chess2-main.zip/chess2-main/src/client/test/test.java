/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client.test;

import client.clientModel.game.Game;
import client.controller.GameController;
import client.view.GameClient;
import client.view.GameFrame;
import client.view.GamePanel;

/**
 *
 * @author nxulu
 */
public class test {
    public static void main(String[] args) {
//        GameFrame gameFrame = new GameFrame("white", "s", "luu", "ha");
//        Game game = new Game(Boolean.TRUE);
//        GamePanel gamePanel = new GamePanel(true, game);
//        GameClient gameClient = new GameClient("luu");
//        GameController gameControler = new GameController(gameFrame, gamePanel, game, gameClient);
    }
}
